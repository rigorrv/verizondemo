package net.android.verizonmedia.networking

import net.android.verizonmedia.model.JsonData
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET

interface Api {

    @GET("soccer_data.json")
    suspend fun getInfo(): Response<JsonData>
}