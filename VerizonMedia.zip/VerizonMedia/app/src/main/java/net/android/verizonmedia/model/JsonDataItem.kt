package net.android.verizonmedia.model

data class JsonDataItem(
    var AwayScore: Int,
    var AwayTeamId: String,
    var AwayTeamName: String,
    var GameId: String,
    var HomeScore: Int = 0,
    var HomeTeamId: String,
    var HomeTeamName: String
)