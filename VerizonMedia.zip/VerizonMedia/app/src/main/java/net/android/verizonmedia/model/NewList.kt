package net.android.verizonmedia.model

data class NewList(
    var AwayScore: Int,
    var AwayTeamId: String,
    var AwayTeamName: String,
    var GameId: String,
    var HomeScore: Int,
    var HomeTeamId: String,
    var HomeTeamName: String
)