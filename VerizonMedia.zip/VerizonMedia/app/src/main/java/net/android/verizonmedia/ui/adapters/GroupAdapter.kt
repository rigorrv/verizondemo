package net.android.verizonmedia.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.group_items.view.*
import net.android.verizonmedia.R
import net.android.verizonmedia.model.JsonDataItem

class GroupAdapter : RecyclerView.Adapter<GroupAdapter.ViewHolder>() {

    var groupListInfo: Map<String, Int> = mapOf()
    var groupList : List<JsonDataItem> = mutableListOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GroupAdapter.ViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.group_items, parent, false)
        return ViewHolder(view)
    }


    override fun onBindViewHolder(holder: GroupAdapter.ViewHolder, position: Int) {
        var result = groupListInfo.keys.toList()
        holder.onBind(result[position])
    }

    override fun getItemCount(): Int {
        return groupListInfo.size
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val teamTxt = itemView.teamTxt
        val winTxt = itemView.winTxt
        val loseTxt = itemView.loseTxt
        val drawTxt = itemView.drawTxt
        val winPercentTxt = itemView.winPercentTxt
        var win = 0

        fun onBind(info: String) {
            teamTxt.text = info

        }
    }
}



