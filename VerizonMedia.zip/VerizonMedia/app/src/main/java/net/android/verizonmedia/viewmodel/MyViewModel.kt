package net.android.verizonmedia.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import net.android.verizonmedia.model.JsonData
import net.android.verizonmedia.networking.Api
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MyViewModel(private val api: Api) : ViewModel() {

    var jsonLiveData = MutableLiveData<JsonData>()

    fun loadInfo() {
        GlobalScope.launch {
            api.getInfo().let {
                jsonLiveData.postValue(it.body())
            }
        }
    }
}