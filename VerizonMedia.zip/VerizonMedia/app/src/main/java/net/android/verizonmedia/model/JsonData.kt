package net.android.verizonmedia.model

class JsonData : ArrayList<JsonDataItem>()