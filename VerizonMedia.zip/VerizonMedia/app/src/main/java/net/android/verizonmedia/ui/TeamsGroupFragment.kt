package net.android.verizonmedia.ui

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.group_items.view.*
import net.android.verizonmedia.databinding.TeamsGroupFragmentBinding
import net.android.verizonmedia.ui.adapters.GroupAdapter
import net.android.verizonmedia.viewmodel.MyViewModel
import org.koin.android.viewmodel.ext.android.viewModel
import java.util.*
import kotlin.collections.HashMap

class TeamsGroupFragment : Fragment() {

    var groupAdapter = GroupAdapter()
    val myViewModel: MyViewModel by viewModel()
    lateinit var teamsGroupFragmentBinding: TeamsGroupFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        teamsGroupFragmentBinding = TeamsGroupFragmentBinding.inflate(inflater, container, false)
        return teamsGroupFragmentBinding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        myViewModel.loadInfo()
        myViewModel.jsonLiveData.observe(viewLifecycleOwner, {

            var result: Map<String, Int> = it.groupingBy { it.HomeTeamName }.eachCount()
            val keyList = ArrayList(result.keys)
            Log.d("TAG", "onViewCreated: ${result}")
            groupAdapter.groupListInfo = result
            teamsGroupFragmentBinding.groupRecyclerView.adapter = groupAdapter
        })
    }


}

